import React, { Component } from 'react';
import './App.css';
import ImageLinkForm from './components/imagelinkform/imagelinkform.js';
import Logo from './components/Logo/logo';
import Rank from './components/Rank/rank';
import Navigation from './components/navigation/navigation';
import Particles from 'react-particles-js';
import Clarifai from 'clarifai';
import Facerecognition from './components/facerecognition/facerecognition'

const paramss = {

    particles: {
      number: {
        value:30,
        density: {
          enable: true,
          value_area: 200
        }
      }
    }
   

}
const app = new Clarifai.App({
  apiKey:'92438785aa8045daa7b2d288fb66bef7'
});
class App extends Component {
  constructor(){
  super();
  this.state = {
    input:'',
    imageurl:'',
    box:{},
  }
  }
  calculatefacelocation = (data)=>{
      const image = document.getElementById('inputimage');
      const face = data[0].region_info.bounding_box;
      const width = Number(image.width);
      const height = Number(image.height);
      console.log(width, height);
      return {
        leftcol :(face.left_col*width)+550+(face.left_col*width),
        toprow : face.top_row*height+height-face.top_row,
        rightcol:width -(face.right_col*width)+550+(face.left_col*width),
        bottomrow:( height - (face.bottom_row*height))-height,
      }


  }
  displayFaceBox = (box) => {
    this.setState({box:box});
    console.log(this.state.box);
  }
 oninputchange = (event)=>{
   this.setState({input:event.target.value});
console.log(event.target.value);
  }
  onButtonsubmit = (event) =>{
    this.setState({imageurl: this.state.input})
    console.log('Click');
    app.models.predict("a403429f2ddf4b49b307e318f00e528b", this.state.input)
    .then(response => this.displayFaceBox(this.calculatefacelocation(response.outputs[0].data.regions)))
    .catch(err=> console.log(err));
    
  }
  render() {
    return (
      <div className="App">
        <Navigation />
        <Logo />
        <Rank />
        <ImageLinkForm oninputchange={this.oninputchange}
        onButtonsubmit={this.onButtonsubmit}/>
        <Particles className="particles" 
              params = {paramss}  />
      <Facerecognition  box={this.state.box} imageurl = {this.state.imageurl} />
       
      </div>
    ); 
  }
}

export default App;
