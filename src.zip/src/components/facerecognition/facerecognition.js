import React from "react";
import './facerecognition.css';

const facerecognition = ({imageurl,box}) =>{
    console.log('second values: ', box);
    return(
        <div className="center la">
        <div className=" mt2 center la">
        <img id="inputimage" src={imageurl} alt={'trial term'} width="500px" height="auto" />  
        <div className='bounding-box' style={{top:box.toprow, right:box.rightcol, bottom:box.bottomrow, left:box.leftcol}}></div>
        </div>
        </div>
    );
}
export default facerecognition;